// const menuBtn = document.querySelector(".navbar-toggler");
// const menu = document.getElementById("main-nav");

// const toggleMenuHandler = (event) => {
//     menu.classList.toggle("show");
// };

// menuBtn.addEventListener("click", toggleMenuHandler);
